import RegisterForm from "../components/RegisterForm";

function RegisterPage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Register</h1>
      <RegisterForm />
    </div>
  );
}

export default RegisterPage;
